#include "Filtros.h"
#include <boost/tuple/tuple.hpp>
#include "gnuplot_i.hpp"
#define length(x) (sizeof(x)/sizeof(x[0]))

Filtros::Filtros(){}

Mat Filtros::e_Grises(Mat image){
    Mat gray(image.rows, image.cols, CV_8UC1);
    for(int i = 0; i < image.rows; i++){
        for(int j = 0; j < image.cols; j++){
            Vec3b pixel = image.at<Vec3b>(i, j);
            //OpenCV usa el orden de color BGR
            uchar b = pixel[0];
            uchar g = pixel[1];
            uchar r = pixel[2];
            gray.at<uchar>(i, j) = (b + g + r) / 3;
            cout << " " << (b + g + r) / 3;
        }
        cout << endl;
    }
    return gray;
}

Mat Filtros::Umbralizacion(Mat img, int umbral){
    Mat binarizada = Mat::zeros(img.size(), img.type());
    for(int i = 0; i<img.rows; i++){
        for(int j = 0; j <img.cols; j++){
            Vec3b pixel = img.at<Vec3b>(i, j);
            int r=pixel.val[2];
            int g=pixel.val[1];
            int b=pixel.val[0];
            if(r>umbral){pixel.val[2]=255;}else{pixel.val[2]=0;}
            if(g>umbral){pixel.val[1]=255;}else{pixel.val[1]=0;}
            if(b>umbral){pixel.val[0]=255;}else{pixel.val[0]=0;}
            binarizada.at<Vec3b>(i, j) = pixel;
        }
    }
    return binarizada;
}

void Filtros::calcularFrecuencias(Mat imagen, int color, double frecuencias[]){
    for(int x=0; x<imagen.rows;x++){
        for(int y=0; y<imagen.cols;y++){
            Vec3b pixel = imagen.at<Vec3b>(x, y);
            int r=pixel.val[2];
            int g=pixel.val[1];
            int b=pixel.val[0];
            //cout << "frecuencias: "<<frecuencias[r]<<"    , r: "<< r << endl;
            if(color == 1){frecuencias[r]++;}
            if(color == 2){frecuencias[g]++;}
            if(color == 3){frecuencias[b]++;}
        }
    }
}

void Filtros::Histograma(double frecuencias[]){
    vector<double> r;
    Gnuplot g1;
    for(int i=0; i<255; i++){
        r.push_back((double)frecuencias[i]);
    }
    g1.set_smooth().plot_x(r,"Frecuencias");
    g1.unset_smooth();
    cin.clear();
    cin.ignore(cin.rdbuf()->in_avail());
    cin.get();
}

void Filtros::Histograma_RGB(Mat img){
    vector<double> r,g,b;
    Gnuplot g1;
    double r_[256]={0};
    double g_[256]={0};
    double b_[256]={0};
    calcularFrecuencias(img, 1, r_);
    calcularFrecuencias(img, 2, g_);
    calcularFrecuencias(img, 3, b_);
    for(int i=0; i<255; i++){
        r.push_back((double)r_[i]);
        g.push_back((double)g_[i]);
        b.push_back((double)b_[i]);
    }
    g1.set_smooth().plot_x(r,"R");
    g1.set_smooth().plot_x(g,"G");
    g1.set_smooth().plot_x(b,"B");
    g1.unset_smooth();
    cin.clear();
    cin.ignore(cin.rdbuf()->in_avail());
    cin.get();
}

void Filtros::imprimir_matriz(Mat img, int canal){
    for(int i=0; i<img.rows; i++){
        for(int j=0; j<img.rows; j++){
            Vec3b pixel = img.at<Vec3b>(i, j);
            int num=0;
            if(canal==1){ ///r
                num=pixel.val[2];
            }else if(canal==2){ ///g
                num=pixel.val[1];
            }else{ ///b
                num=pixel.val[0];
            }
            cout << " " <<num;
        }
        cout <<endl;
    }
    cout <<endl;
}

double Filtros::min_max(Mat img, int op){
    double min, max, res;
    minMaxIdx(img, &min, &max);
    if(op==1){res=max;}else{res=min;} //opcion 1 = maximo
    return res;
}

void Filtros::imprimirRGB(Mat img){
    for(int i=0; i<img.rows; i++){
        for(int j=0; j<img.rows; j++){
            Vec3b pixel = img.at<Vec3b>(i, j);
            cout << pixel <<" ";
        }
        cout <<endl;
    }
    cout <<endl;
}
