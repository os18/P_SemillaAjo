#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
/*
using namespace std;
using namespace cv;

int threshold_type = 4;
Mat src, dst;
char* window_name = "Convolución por canales";
char* trackbar_type = "0: R\n 1: G\n 2: B\n 3: RGB \n";

void funcion_llamada(int, void*){
    threshold(src, dst, 100, 255,threshold_type);
    imshow(window_name, dst);
}

int main(){
    src = imread("../ICSAMPI/img/parcela/IP_1.JPG", IMREAD_COLOR);
    namedWindow(window_name, WINDOW_AUTOSIZE);
    createTrackbar(trackbar_type, window_name, &threshold_type, 3, funcion_llamada;
    funcion_llamada(0, 0);
    while(true){ int c = waitKey(20);}
}


*/
