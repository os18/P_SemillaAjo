#ifndef GESTOR_H_INCLUDED
#define GESTOR_H_INCLUDED

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>

using namespace cv;
using namespace std;

class Gestor{
    private:
        Mat imgOriginal;
        String dir;

    public:
        Gestor();
        Gestor(String directorio);
        Mat obtenerImagen();
        Mat recortarImg(Mat, int, int, int, int);
        void establecerImagen(Mat imagen);
        void establecerDirectorio(String);
        void cargarImagen();
        void guardarImagen(Mat, String);
        void visualizar(Mat, String);
};

#endif // GESTOR_H_INCLUDED
