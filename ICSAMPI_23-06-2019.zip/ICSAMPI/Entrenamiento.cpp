#include <opencv2/opencv.hpp>

using namespace cv;
using namespace std;

int main(){/* \\*/
	String TEST_DIR = "/home/os/Documents/Entrenamiento_color/data/test/";
	String SEM_CXML = "/home/os/Documents/Entrenamiento_color/data/cascade.xml";
	String NAME_WIN = "Entrenamiento";

	CascadeClassifier semilla;

	if(!semilla.load(SEM_CXML)){cout<<"Error en el archivo:" + SEM_CXML<<endl; return -1;};
	for(int i = 0; i < 6; i++){
		stringstream number;
		number << i;
        String image_test = TEST_DIR + number.str() + ".JPG";
		//cout<<"ns: "<<image_test<<endl;
		Mat image = imread(image_test, 1);
		if(!image.data){cout<<"No image data."<<endl; return -1;}

		vector<Rect> rc;
		semilla.detectMultiScale(image, rc, 1.5, 3, 2);
		for(size_t i = 0; i < rc.size(); i++){
			rectangle(image, Point(rc[i].x, rc[i].y), Point(rc[i].x + rc[i].width, rc[i].y + rc[i].height), CV_RGB(0, 255, 0), 1);
		}

		namedWindow(NAME_WIN, WINDOW_AUTOSIZE);
		imshow(NAME_WIN, image);
		//String name_ = "/home/os/Documents/Pruebas_Sample/r7_15stages__minNei2"+number.str()+".JPG";
		//imwrite(name_, image);
		waitKey(0);
	}
	return 0;
}
