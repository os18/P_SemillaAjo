#ifndef FILTROS_H_INCLUDED
#define FILTROS_H_INCLUDED

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include <math.h>
#include <stdlib.h>
#include <vector>
#include <cmath>
#define dm 14

using namespace std;
using namespace cv;

class Filtros{
    public:
        Filtros();
        Mat e_Grises(Mat);
        Mat Umbralizacion(Mat, int);
        Mat expansionLineal(int, int, Mat);
        Mat umbralizacion_otsu(Mat);
        double min_max(Mat, int);
        void Histograma(double []);
        void Histograma_RGB(Mat);
        void calcularFrecuencias(Mat, int, double[]);
        void obtener_matrizKernel(Mat, int, int[dm][dm]);
        void imprimirRGB(Mat);
};

#endif // FILTROS_H_INCLUDED
