#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include "Gestor.h"
#include "Filtros.h"
#include "Convolucion.h"
#include "DeteccionLineas.h"

using namespace std;
using namespace cv;

int main(){
    //string dir("../ICSAMPI/img/parcela/IP_1.JPG");
    string dir("../ICSAMPI/img/2.JPG");
    Gestor ge(dir);
    ge.cargarImagen();

    if(!(ge.obtenerImagen().empty())){
        Mat original=ge.obtenerImagen();
        Filtros f;
        f.imprimir_matriz(original, 1);
        f.imprimir_matriz(original, 2);
        f.imprimir_matriz(original, 3);

        string dir2("../ICSAMPI/img/parcela/IP_1.JPG");
        Gestor g2(dir2);
        g2.cargarImagen();
        Mat parcela=g2.obtenerImagen();
        g2.visualizar(parcela, "Parcela");

        ///R
        int matriz[][5]={{210, 233, 232, 224, 211},
                         {231, 253, 255, 254, 255},
                         {228, 255, 255, 251, 254},
                         {189, 227, 255, 253, 255},
                         {159, 196, 246, 253, 234}};
        Convolucion r(parcela);
        r.asignarMatriz(matriz);
        Mat conv=r.convolucion_porCanal(1);
        g2.visualizar(conv, "Convolucion R");

        ///G
        int matri1[][5]={{193, 215, 214, 206, 192},
                         {216, 247, 240, 236, 237},
                         {213, 243, 243, 237, 242},
                         {174, 211, 243, 249, 240},
                         {144, 182, 232, 237, 218}};
        Convolucion g(parcela);
        g.asignarMatriz(matri1);
        Mat convg=g.convolucion_porCanal(2);
        g2.visualizar(convg, "Convolucion G");

        ///B
        int matri2[][5]={{186, 213, 212, 204, 188},
                         {211, 247, 243, 234, 235},
                         {210, 243, 243, 236, 242},
                         {169, 211, 243, 248, 237},
                         {139, 181, 231, 237, 218}};
        Convolucion b(parcela);
        b.asignarMatriz(matri2);
        Mat convb=b.convolucion_porCanal(3);
        g2.visualizar(convb, "Convolucion B");

        ///RGB en la parcela
        Convolucion RGB_(parcela);
        RGB_.asignarMatriz(matriz);
        Mat covrgb = RGB_.aplicar();
        g2.visualizar(covrgb, "RGB");

        //ge.guardarImagen(conv, "/home/os/Documents/Pruebas/convolucionR_semilla.JPG");
    }
    cout << "Fin del programa" << endl;
    return 0;
}

