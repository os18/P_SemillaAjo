#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include "Gestor.h"
#include "Filtros.h"
#include "Convolucion.h"

using namespace std;
using namespace cv;

int main(){
    Gestor ge1("../ICSAMPI/img/1.JPG");
    ge1.cargarImagen();
    Mat sem = ge1.obtenerImagen();

    if(!(sem.empty())){
        Filtros f;
        Convolucion conv;

        int kernelR[dim][dim]={0};
        conv.obtener_matrizKernel(sem, 2, kernelR);
        int kernelG[dim][dim];
        conv.obtener_matrizKernel(sem, 1, kernelG);
        int kernelB[dim][dim];
        conv.obtener_matrizKernel(sem, 0, kernelB);

        Gestor ge("../ICSAMPI/img/Im1.JPG");
        ge.cargarImagen();
        Mat parcela=ge.obtenerImagen();
        ge.visualizar(parcela, "Parcela");

        conv.asignarImagen(parcela);
        conv.asignarMatriz(kernelR);
        conv.convolucionMatriz(2);
        conv.asignarMatriz(kernelG);
        conv.convolucionMatriz(1);
        conv.asignarMatriz(kernelB);
        conv.convolucionMatriz(0);

        Mat imgconv = conv.obtenerImgConv();
        ge.visualizar(imgconv, "Convolucion");
    }

    cout <<"Fin del programa" << endl;
    return 0;
}
