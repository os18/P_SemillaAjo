#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include "Gestor.h"
#include "Filtros.h"
#include "Convolucion.h"

using namespace std;
using namespace cv;

int main(){
    string dir1("../ICSAMPI/img/1.JPG");
    Gestor ge1(dir1);
    ge1.cargarImagen();

    if(!(ge1.obtenerImagen().empty())){
        Mat sem=ge1.obtenerImagen();
        ge1.visualizar(sem, "Semilla");
        Filtros f;
        f.imprimirRGB(sem);

        int kernelR[dim][dim]={0};
        f.obtener_matrizKernel(sem, 2, kernelR);
        int kernelG[dim][dim]={0};
        f.obtener_matrizKernel(sem, 1, kernelG);
        int kernelB[dim][dim]={0};
        f.obtener_matrizKernel(sem, 0, kernelB);

        string dir("../ICSAMPI/img/parcela/Im1.JPG");
        Gestor ge(dir);
        ge.cargarImagen();
        Mat parcela=ge.obtenerImagen();
        ge.visualizar(parcela, "Parcela");

        Convolucion conv(parcela);
        conv.asignarMatriz(kernelR);
        conv.convolucionMatriz(2);
        conv.asignarMatriz(kernelG);
        conv.convolucionMatriz(1);
        conv.asignarMatriz(kernelB);
        conv.convolucionMatriz(0);
        Mat imgconv = conv.obtenerImgConv();
        ge.visualizar(imgconv, "Convolucion");
    }
    cout <<"Fin del programa" << endl;
    return 0;
}
