#include "Gestor.h"

Gestor::Gestor(){}

Gestor::Gestor(String directorio){
    dir=directorio;
}

Mat Gestor::obtenerImagen(){
    return imgOriginal;
}

Mat Gestor::recortarImg(Mat img, int largo, int alto, int x, int y){
    Rect corte(x,y,largo, alto);
    Mat recortada = img(corte);
    return recortada;
}

void Gestor::establecerImagen(Mat imagen){
    imgOriginal=imagen;
}

void Gestor::establecerDirectorio(String directorio){
    dir=directorio;
}

void Gestor::cargarImagen(){
    imgOriginal = imread(dir, IMREAD_COLOR); //abrir imgenes
    if(imgOriginal.empty()){
        cout << "Could not open or find the image" << endl ;
    }
}

void Gestor::guardarImagen(Mat imagen, String directorio){
    imwrite(directorio, imagen);
}

void Gestor::visualizar(Mat imagen, String nombre){
    namedWindow(nombre, WINDOW_AUTOSIZE );
    imshow(nombre, imagen);
    waitKey(0);
}
