#include <opencv2/opencv.hpp>
#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
/*
using namespace cv;
using namespace std;

int main(int argc, char** argv){
	String TEST_DIR = "/home/os/Documents/Tesis/ICSAMPI/Entrenamiento/Test";
	String SEM_CXML = "/home/os/Documents/Tesis/ICSAMPI/Entrenamiento/data";
	CascadeClassifier ident_semilla;

	if (!ident_semilla.load(SEM_CXML)){
        cout<<"Error en el archivo: " + SEM_CXML <<endl;
        return -1;
    };

	for(int i = 0; i < 20; i++){
		std::stringstream number;
		number << i;
		string image_test("../ICSAMPI/img/2_.JPG");
		Mat image = imread(image_test, 1);
		if(!image.data){
            cout<<"No image data."<<endl;
            return -1;
        }

		vector<Rect> rc;
		ident_semilla.detectMultiScale(image, rc, 1.1, 8);

		for(int i=0; i<rc.size(); i++){
			rectangle(image, Point(rc[i].x, rc[i].y),
                Point(rc[i].x + rc[i].width, rc[i].y + rc[i].height),
                CV_RGB(0, 255, 0), 1);
		}

		namedWindow("Entrenamiento", WINDOW_AUTOSIZE);
		imshow("Entrenamiento", image);
		waitKey(0);
	}
	return 0;
}
*/
