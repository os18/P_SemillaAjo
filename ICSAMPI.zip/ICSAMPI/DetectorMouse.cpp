#include "opencv2/highgui/highgui.hpp"
#include <iostream>
/*
using namespace std;
using namespace cv;

void CallBackFunc(int event, int x, int y, int flags, void* userdata){
     if(event == EVENT_LBUTTONDOWN ){
          cout << "Boton izquierdo presionado - Posicion("<< x <<", "<< y <<")"<< endl;
     }else if(event == EVENT_RBUTTONDOWN ){
          cout << "Boton derecho presionado - Posicion("<< x <<", "<< y <<")"<< endl;
     }else if(event == EVENT_MBUTTONDOWN ){
          cout << "Boton medio presionado - Posicion("<< x <<", "<< y <<")"<< endl;
     }else if(event == EVENT_MOUSEMOVE ){
          cout << "Mouse en la ventana - posicion("<< x <<", "<< y <<")"<< endl;
     }
}

int main(int argc, char** argv){
     Mat img = imread("../ICSAMPI/img/IP_6.JPG");
     if(img.empty()){
        cout<< "Error loading the image" << endl;
        return -1;
     }
     namedWindow("My Window", 1);
     setMouseCallback("My Window", CallBackFunc, NULL);
     imshow("My Window", img);
     waitKey(0);
     return 0;
}

*/
