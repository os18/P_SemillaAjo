#ifndef CONVOLUCION_H
#define CONVOLUCION_H

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <math.h>
#define length(x) (sizeof(x)/sizeof(x[0]))
#define dim 14

using namespace cv;
using namespace std;

class Convolucion{
    private:
        Mat imagenOriginal;
        Mat imgConv;
        int kernel[dim][dim]={0};
        int divisor=1;
        int kleng;

    public:
        Convolucion();
        void asignarMatriz(int [dim][dim]);
        void convolucionMatriz(int);
        void obtener_FragImg(int [dim][dim], int, int, int);
        void obtener_matrizKernel(Mat, int, int[dim][dim]);
        void imprimir(Mat);
        void normalizar(Mat, int);
        long funcion_max(Mat);
        long funcion_min(Mat);
        void asignarImagen(Mat);
        Mat obtenerImgConv();

        Mat otraFuncion(Mat);
        Mat otraNormalizacion(Mat);
};

#endif // CONVOLUCION_H
