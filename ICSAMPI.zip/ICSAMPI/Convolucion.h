#ifndef CONVOLUCION_H
#define CONVOLUCION_H

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <math.h>

#define dim 5
#define di2 5

using namespace cv;
using namespace std;

template <class T, std::size_t N>
size_t CountOf(const T (&array)[N]){return N;}

class Convolucion{
    private:
        Mat imagenOriginal;
        int kernel[di2][dim]={0};
        int divisor=1;
        int tam_kernel= CountOf(kernel[0]);

    public:
        Convolucion(Mat);
        Mat aplicar();
        void asignarMatriz(int [di2][dim]);
        void extraerMuestra(int, int, Vec3b [][dim]); //arreglo retornado por referencia
        void convolucionar(Vec3b[][dim], int[]); //arreglo retornado por referencia
        //void obtenerKernel(Mat int [][]);
        Mat convolucion_porCanal(int);
        void Ext_muestra(int, int, int [][dim], int);
        int convolucion(int [][dim]);
};

#endif // CONVOLUCION_H
