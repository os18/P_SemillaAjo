#include "Convolucion.h"

Convolucion::Convolucion(Mat img){
    imagenOriginal = img.clone();
    imgConv = Mat::zeros(img.size(), img.type());
}

void Convolucion::asignarMatriz(int k[dim][dim]){
    for(int i=0; i<dim; i++){
        for(int j=0; j<dim; j++){
            kernel[i][j]=k[i][j];
        }
    }
}

void Convolucion::convolucionMatriz(int canal){ //canal=> 0,1 o 2
    kleng=length(kernel);
    mitad=length(kernel) / 2;
    long acumulador;
    Mat nueva(imagenOriginal.size(), CV_32SC3);
    //long matrizNueva[imagenOriginal.rows][imagenOriginal.cols];

    for(int ii=0; ii<imagenOriginal.rows; ii++){
        for(int jj=0; jj<imagenOriginal.cols; jj++){
            int fragImg[dim][dim]={0};
            obtener_FragImg(fragImg, ii, jj, canal);
            acumulador=0;
            for(int x=0; x<kleng; x++){
                for(int y=0; y<kleng; y++){
                    acumulador+=(kernel[x][y]*fragImg[x][y]);
                }
            }
            acumulador/=divisor;
            //matrizNueva[ii][jj]=acumulador;
            //cout<<matrizNueva[ii][jj]<<" ";
            nueva.at<long>(ii, jj) = acumulador;
            //cout<<ii<<" "<<jj<<endl;
        }
        //cout<<endl;
    }
    cout <<"Canal: "<<canal;
    imprimir(nueva);
    normalizar(nueva, canal);
}

void Convolucion::obtener_FragImg(int matriz[dim][dim], int ii, int jj, int canal){
    int xx=0, yy=0;
    for(int i = ii-(kleng-1)/2; i <= ii+(kleng-1)/2; i++){
        for(int j=jj-(kleng-1)/2; j <= jj+(kleng-1)/2; j++){
            if((j<0 || i<0) || (i>=imagenOriginal.rows || j>=imagenOriginal.cols)){
            	matriz[xx][yy] = 0;
            }else{
            	Vec3b pixel = imagenOriginal.at<Vec3b>(i, j);
            	matriz[xx][yy] = pixel.val[canal];
            }
            yy++;
        }
        yy=0;
        xx++;
    }
    //imprimir_matriz(matriz);
    //cout<<endl;
}

/*void Convolucion::imprimir_matriz(int matriz[dim][dim]){
    for(int i=0; i<dim; i++){
        for(int j=0; j<dim; j++){
            cout<<matriz[i][j]<<" ";
        }
        cout<<endl;
    }
    cout << endl;
}*/

void Convolucion::imprimir(Mat img){
    cout << endl << endl;
    for(int i=0; i<img.rows; i++){
        for(int j=0; j<img.cols; j++){
            long num = img.at<long>(i, j);
            cout <<" "<<num;
        }
        cout <<endl;
    }
    cout <<endl;
}

void Convolucion::normalizar(Mat matrizImg, int canal){
    ///calcular maximo
    cout <<"Canal: "<<canal<<endl;
    long maximo=funcion_max(matrizImg);
    long minimo=funcion_min(matrizImg);
    cout <<"Maximo: "<<maximo<<endl;
    //cout <<"Otro_ Maximo: "<<ordenar(matrizImg,(matrizImg.cols*matrizImg.rows)-1)<<endl;
    cout <<"Minimo: "<<minimo<<endl;
    //cout <<"Otro_ Minimo: "<<ordenar(matrizImg,0)<<endl;
    imgConv = Mat::zeros(imagenOriginal.size(), CV_8UC3);

    for(int x=0; x<matrizImg.rows; x++){
        for(int y=0; y<matrizImg.cols; y++){
            ///obtener el valor de la matriz
            long valor = matrizImg.at<long>(x, y);
            ///valor*255 / maximo
            int res=(valor-minimo)*255/(maximo-minimo);
            cout <<res<<" ";
            ///agregar a la imagen en el canal determinado
            imgConv.at<cv::Vec3b>(x,y)[canal] = res;
            //imgConv.at<Vec3b>(x, y) = pixel;
        }
        cout <<endl;
    }
}

long Convolucion::funcion_max(Mat matrizImg){
    long mayor = matrizImg.at<long>(0, 0);
    for(int i=0; i<matrizImg.rows; i++){
        for(int j=0; j<matrizImg.cols; j++){
            long valor = matrizImg.at<long>(i, j);
            if(valor > mayor){
                mayor=valor;
            }
        }
    }
    return mayor;
}

long Convolucion::funcion_min(Mat matrizImg){
    long menor = matrizImg.at<long>(0, 0);
    for(int i=0; i<matrizImg.rows; i++){
        for(int j=0; j<matrizImg.cols; j++){
            long valor = matrizImg.at<long>(i, j);
            if(valor < menor){
                menor=valor;
            }
        }
    }
    return menor;
}

Mat Convolucion::obtenerImgConv(){
    return imgConv;
}

long Convolucion::ordenar(Mat vec, int pos){
    long tamano=vec.rows*vec.cols;
    long ordenado[tamano]={0};
    int cont=0;
    for(long i=0; i<vec.rows; i++){
        for(long j=0; j<vec.cols; j++){
            ordenado[cont]=vec.at<long>(i, j);
            cont++;
        }
    }

    for(long i=0; i<tamano; i++){
        for(long j=i+1; j<tamano; j++){
            if(ordenado[j] < ordenado[i]){
                long temp = ordenado[j];
                ordenado[j] = ordenado[i];
                ordenado[i] = temp;
            }
        }
    }
    return ordenado[pos];
}
