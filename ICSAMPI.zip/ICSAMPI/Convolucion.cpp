#include "Convolucion.h"

Convolucion::Convolucion(){}

Mat Convolucion::asignarImagen(Mat img){
      imagenOriginal = img.clone();
      imgConv = Mat::zeros(img.size(), img.type());
}

void Convolucion::asignarMatriz(int k[dim][dim]){
    for(int i=0; i<dim; i++){
        for(int j=0; j<dim; j++){
            kernel[i][j]=k[i][j];
    }}
}

void Convolucion::convolucionMatriz(int canal){
    kleng=length(kernel);
    mitad=length(kernel) / 2;
    Mat nueva(imagenOriginal.size(), CV_32SC3);

    for(int ii=0; ii<imagenOriginal.rows; ii++){
        for(int jj=0; jj<imagenOriginal.cols; jj++){
            int fragImg[dim][dim]={0};
            obtener_FragImg(fragImg, ii, jj, canal);
            long acumulador=0;
            for(int x=0; x<kleng; x++){
                for(int y=0; y<kleng; y++){
                    acumulador+=(kernel[x][y]*fragImg[x][y]);
                }
            }
            acumulador/=divisor;
            nueva.at<long>(ii, jj) = acumulador;
        }
    }
    //cout<<"Canal: "<<canal;
    imprimir(nueva);
    normalizar(nueva, canal);
}

void Convolucion::obtener_FragImg(int matriz[dim][dim], int ii, int jj, int canal){
    int xx=0, yy=0;
    for(int i = ii-(kleng-1)/2; i <= ii+(kleng-1)/2; i++){
        for(int j=jj-(kleng-1)/2; j <= jj+(kleng-1)/2; j++){
            if((j<0 || i<0) || (i>=imagenOriginal.rows || j>=imagenOriginal.cols)){
            	matriz[xx][yy] = 0;
            }else{
            	Vec3b pixel = imagenOriginal.at<Vec3b>(i, j);
            	matriz[xx][yy] = pixel.val[canal];
            }
            yy++;
        }
        yy=0;
        xx++;
    }
}

void Convolucion::imprimir(Mat img){
    cout<< "Img nueva "<< endl;
    for(int i=0; i<img.rows; i++){
        for(int j=0; j<img.cols; j++){
            cout <<" "<<img.at<long>(i, j);
        }cout <<endl;
    }cout <<endl;
}

void Convolucion::normalizar(Mat matrizImg, int canal){
    cout <<"Canal: "<<canal<<endl;
    long maximo=funcion_max(matrizImg);
    long minimo=funcion_min(matrizImg);
    cout <<"Maximo: "<< maximo<< endl<< "Minimo: "<< minimo<< endl;

    for(int x=0; x<matrizImg.rows; x++){
        for(int y=0; y<matrizImg.cols; y++){
            long valor = matrizImg.at<long>(x, y);
            int res=(valor-minimo)*255/(maximo-minimo);
            cout <<res<<" ";
            imgConv.at<cv::Vec3b>(x,y)[canal] = res;
        }cout <<endl;
    }
}

/*Mat Convolucion::otraFuncion(Mat imagen){
    Mat nueva(imagenOriginal.size(), CV_32SC1);
    for(int x=0; x<imagen.rows; x++){
        for(int y=0; y<imagen.cols; y++){
            Vec3b pixel = imagen.at<Vec3b>(x, y);
            uchar b = pixel[0];
            uchar g = pixel[1];
            uchar r = pixel[2];
            long valor = (b + g + r) / 3;
            nueva.at<long>(x, y) = valor;
        }
        cout <<endl;
    }
    otraNormalizacion(nueva);
}

Mat Convolucion::otraNormalizacion(Mat imagen){
    long maximo=funcion_max(imagen);
    long minimo=funcion_min(imagen);
    Mat nueva(imagenOriginal.size(), CV_8UC1);
    for(int x=0; x<imagen.rows; x++){
        for(int y=0; y<imagen.cols; y++){
            long valor = imagen.at<long>(x, y);
            int res=(valor-minimo)*255/(maximo-minimo);
            cout <<res<<" ";
            nueva.at<int>(x,y)= res;
        }
        cout <<endl;
    }
    return nueva;
}*/

long Convolucion::funcion_max(Mat matrizImg){
    long mayor = matrizImg.at<long>(0, 0);
    for(int i=0; i<matrizImg.rows; i++){
        for(int j=0; j<matrizImg.cols; j++){
            long valor = matrizImg.at<long>(i, j);
            if(valor > mayor){
                mayor=valor;
            }
        }
    }
    return mayor;
}

long Convolucion::funcion_min(Mat matrizImg){
    long menor = matrizImg.at<long>(0, 0);
    for(int i=0; i<matrizImg.rows; i++){
        for(int j=0; j<matrizImg.cols; j++){
            long valor = matrizImg.at<long>(i, j);
            if(valor < menor){
                menor=valor;
            }
        }
    }
    return menor;
}

Mat Convolucion::obtenerImgConv(){
    return imgConv;
}

void Convolucion::obtener_matrizKernel(Mat img, int canal, int mkernel[dim][dim]){
    for(int i=0; i<img.rows; i++){
        for(int j=0; j<img.rows; j++){
            Vec3b pixel = img.at<Vec3b>(i, j);
            mkernel[i][j]=pixel.val[canal];
            cout<<mkernel[i][j]<<" ";
        }
        cout <<endl;
    }
    cout <<endl;
}
