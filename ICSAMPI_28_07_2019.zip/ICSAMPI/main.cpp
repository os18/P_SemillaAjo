#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include "Gestor.h"
#include "Filtros.h"
#include "Convolucion.h"

using namespace cv;
using namespace std;

int main(int argc, char** argv){
    Filtros f;
    Convolucion cnv;
    //Gestor g("../ICSAMPI/img/1.JPG");
    Gestor g("../ICSAMPI/img/1.JPG");
    g.cargarImagen();
    Mat src = g.obtenerImagen();
    int kernelR[14][14]={0};
    cnv.obtener_matrizKernel(src,2,kernelR);
    int kernelG[14][14]={0};
    cnv.obtener_matrizKernel(src,1,kernelG);
    int kernelB[14][14]={0};
    cnv.obtener_matrizKernel(src,0,kernelB);


    Gestor g1("../ICSAMPI/img/Im1.JPG");
    g1.cargarImagen();
    Mat src2 = g1.obtenerImagen();
    cnv.asignarImagen(src2);
    cnv.Convolucion(2);
    cnv.Convolucion(1);
    cnv.Convolucion(0);
    Mat conv=cnv.obtenerImgConv();
    g1.visualizar(conv, "convol");

    // int kernel[7][7]={0};
    //cnv.obtener_matrizKernel(gris, 1, kernel);

    /*Mat kernel = (Mat_<char>(5, 5) << 1,  4,  7,  4, 1,
                                      4, 16, 26, 16, 4,
                                      7, 26, 41, 26, 7,
                                      4, 16, 26, 16, 4,
                                      1, 4, 7, 4, 1);*/

    /*Mat kernel = (Mat_<char>(3, 3) << 0, 1, 0,
                                      1, -4, 1,
                                      0, 1, 0);*/

    /*Mat kernel = (Mat_<char>(7, 7) << 145, 155, 144, 184, 150, 243, 160,
                                      183, 171, 136, 232, 130, 242, 199,
                                      198, 212, 134, 247, 132, 240, 223,
                                      184, 243, 148, 241, 148, 210, 196,
                                      182, 242, 158, 223, 138, 141, 144,
                                      172, 212, 159, 168, 118,  0, 0,
                                      143, 157,  0,   0,  0,  0, 0);*/

    //cv::filter2D(src, dst, src.depth(), kernel);

    //g.guardarImagen(can, "/home/os/Documents/can4_.JPG");
    waitKey(0);
    return 0;
}
