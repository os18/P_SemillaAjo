#ifndef FILTROS_H_INCLUDED
#define FILTROS_H_INCLUDED

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <string>
#include <math.h>
#include <stdlib.h>
#include <vector>
#include <cmath>

using namespace std;
using namespace cv;

class Filtros{
    public:
        Filtros();
        Mat e_Grises(Mat);
        Mat Umbralizacion(Mat, int);
        void Histograma(double []);
        void Histograma_RGB(Mat);
        void calcularFrecuencias(Mat, int, double[]);
        void imprimirRGB(Mat);
        Mat gauss_dif(Mat);
        Mat tHough(Mat);
        Mat f_canny(Mat);
};

#endif // FILTROS_H_INCLUDED
