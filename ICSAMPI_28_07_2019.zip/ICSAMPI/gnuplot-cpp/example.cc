// Example for C++ Interface to Gnuplot

// requirements:
// * gnuplot has to be installed (http://www.gnuplot.info/download.html)
// * for Windows: set Path-Variable for Gnuplot path (e.g. C:/program files/gnuplot/bin)
//             or set Gnuplot path with: Gnuplot::set_GNUPlotPath(const std::string &path);


#include <iostream>
#include "gnuplot_i.hpp" //Gnuplot class handles POSIX-Pipe-communikation with Gnuplot

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__TOS_WIN__)
 #include <conio.h>   //for getch(), needed in wait_for_key()
 #include <windows.h> //for Sleep()
 void sleep(int i) { Sleep(i*1000); }
#endif

#define SLEEP_LGTH 2  // sleep time in seconds
#define NPOINTS    50 // length of array

void wait_for_key(); // Programm halts until keypress

using std::cout;
using std::endl;

int main(int argc, char* argv[]){
    try{
        std::vector<double> x, y, y2, dy, z;

        for (int i = 0; i < NPOINTS; i++)  /* fill double arrays x, y, z*/{
            x.push_back((double)i);             // x[i] = i
            y.push_back((double)i * (double)i); // y[i] = i^2
            z.push_back( x[i]*y[i] );           // z[i] = x[i]*y[i] = i^3
            dy.push_back((double)i * (double)i / (double) 10); // dy[i] = i^2 / 10
        }
        y2.push_back(0.00); y2.push_back(0.78); y2.push_back(0.97); y2.push_back(0.43);
        y2.push_back(-0.44); y2.push_back(-0.98); y2.push_back(-0.77); y2.push_back(0.02);

        Gnuplot g2;
        cout << "window 2: user defined points" << endl;
        g2.plot_x(y2,"points");
        g2.set_smooth().plot_x(y2,"cspline");
        g2.set_smooth("bezier").plot_x(y2,"bezier");
        g2.unset_smooth();

        
        // Plot an image
        Gnuplot g9;
        cout << "window 9: plot_image" << endl;
        const int iWidth  = 255;
        const int iHeight = 255;
        g9.set_xrange(0,iWidth).set_yrange(0,iHeight).set_cbrange(0,255);
        g9.cmd("set palette gray");
        unsigned char ucPicBuf[iWidth*iHeight];
        // generate a greyscale image
        for(int iIndex = 0; iIndex < iHeight*iWidth; iIndex++){
            ucPicBuf[iIndex] = iIndex%255;
        }
        g9.plot_image(ucPicBuf,iWidth,iHeight,"greyscale");
        g9.set_pointsize(0.6).unset_legend().plot_slope(0.8,20);

        // manual control
        Gnuplot g10;
        cout << "window 10: manual control" << endl;
        g10.cmd("set samples 400").cmd("plot abs(x)/2"); // either with cmd()
        g10 << "replot sqrt(x)" << "replot sqrt(-x)";    // or with <<

        wait_for_key();

    }catch (GnuplotException ge){cout << ge.what() << endl;}

    return 0;
}



void wait_for_key (){
#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__TOS_WIN__)  // every keypress registered, also arrow keys
    cout << endl << "Press any key to continue..." << endl;

    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    _getch();
#elif defined(unix) || defined(__unix) || defined(__unix__) || defined(__APPLE__)
    cout << endl << "Press ENTER to continue..." << endl;

    std::cin.clear();
    std::cin.ignore(std::cin.rdbuf()->in_avail());
    std::cin.get();
#endif
    return;
}
